import React from 'react';
import {render} from 'react-dom';
import Hums3d from './hums3d.jsx';

render(<Hums3d/>, document.getElementById("root"));